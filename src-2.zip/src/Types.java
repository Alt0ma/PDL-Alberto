import java.util.ArrayList;

public class Types {
	
	public Types(){
	}

	public ArrayList<String> getList(){
		ArrayList<String> tipos = new ArrayList<String>();
		tipos.add("boleano");
		tipos.add("int");
		tipos.add("string");
		tipos.add("funcion");
		tipos.add("not defined");
		return tipos;
	}


}
